function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6WaQHY8F5BT":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

